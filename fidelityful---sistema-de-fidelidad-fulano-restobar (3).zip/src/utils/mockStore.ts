import {
  User,
  MenuItem,
  Transaction,
  Reward,
  Redemption,
  SystemConfig,
  AnalyticsData,
  UserDetailsResponse,
  BdpOrder,
  ClaimedTicket,
  ClaimTicketResult,
  Coupon,
  TransactionItem,
  BdpOrderItem,
  PointAdjustment,
} from '../types';

export const DEFAULT_CONFIG: SystemConfig = {
  id: 1,
  euro_to_points: 10,
  multiplier_bebida: 1.0,
  multiplier_coctel: 1.5,
  multiplier_plato: 2.0,
  multiplier_postre: 1.2,
  birthday_bonus_points: 150,
  visit_milestone: 10,
  level_plata_threshold: 1000,
  level_plata_bonus_pct: 5,
  level_oro_threshold: 3000,
  level_oro_bonus_pct: 10,
  level_vip_threshold: 7000,
  level_vip_bonus_pct: 20,
  updated_at: new Date().toISOString(),
};

export const DEFAULT_USERS: User[] = [
  {
    id: 1,
    uid: 'USR-ADMIN-01',
    name: 'Carlos Menéndez',
    email: 'admin@fulano.com',
    phone: '+34 600 111 222',
    birthday: '1982-05-14',
    points: 0,
    total_spent: 0,
    total_visits: 0,
    level: 'VIP',
    role: 'admin',
    avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
    created_at: '2025-01-01T00:00:00.000Z',
    last_activity_at: new Date().toISOString(),
  },
  {
    id: 2,
    uid: 'USR-STAFF-01',
    name: 'Lucía Santos',
    email: 'staff@fulano.com',
    phone: '+34 611 333 444',
    birthday: '1995-09-22',
    points: 0,
    total_spent: 0,
    total_visits: 0,
    level: 'Plata',
    role: 'staff',
    avatar_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=250&q=80',
    created_at: '2025-01-01T00:00:00.000Z',
    last_activity_at: new Date().toISOString(),
  },
  {
    id: 3,
    uid: 'USR-CLI-001',
    name: 'Sofía Morales',
    email: 'sofia@ejemplo.com',
    phone: '+34 622 456 789',
    birthday: '1994-11-20',
    points: 3450,
    total_spent: 345.0,
    total_visits: 14,
    level: 'Oro',
    role: 'client',
    avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80',
    created_at: '2025-01-01T00:00:00.000Z',
    last_activity_at: new Date().toISOString(),
  },
  {
    id: 4,
    uid: 'USR-CLI-002',
    name: 'Mateo García',
    email: 'mateo@ejemplo.com',
    phone: '+34 633 987 654',
    birthday: '1998-04-12',
    points: 1420,
    total_spent: 138.0,
    total_visits: 9,
    level: 'Plata',
    role: 'client',
    avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80',
    created_at: '2025-01-01T00:00:00.000Z',
    last_activity_at: new Date().toISOString(),
  },
  {
    id: 5,
    uid: 'USR-CLI-003',
    name: 'Elena Ramos',
    email: 'elena@ejemplo.com',
    phone: '+34 644 112 233',
    birthday: '1989-08-05',
    points: 8200,
    total_spent: 820.0,
    total_visits: 32,
    level: 'VIP',
    role: 'client',
    avatar_url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=250&q=80',
    created_at: '2025-01-01T00:00:00.000Z',
    last_activity_at: new Date().toISOString(),
  },
  {
    id: 6,
    uid: 'USR-CLI-004',
    name: 'David Torres',
    email: 'david@ejemplo.com',
    phone: '+34 655 778 899',
    birthday: '1996-10-14',
    points: 450,
    total_spent: 45.0,
    total_visits: 3,
    level: 'Bronce',
    role: 'client',
    avatar_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=250&q=80',
    created_at: '2025-01-01T00:00:00.000Z',
    last_activity_at: new Date().toISOString(),
  },
  {
    id: 7,
    uid: 'USR-CLI-005',
    name: 'Carmen Navarro',
    email: 'carmen@ejemplo.com',
    phone: '+34 666 332 211',
    birthday: '2001-02-18',
    points: 120,
    total_spent: 12.0,
    total_visits: 1,
    level: 'Bronce',
    role: 'client',
    avatar_url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=250&q=80',
    created_at: '2025-01-01T00:00:00.000Z',
    last_activity_at: new Date().toISOString(),
  },
];

export const DEFAULT_REWARDS: Reward[] = [
  {
    id: 1,
    name: 'Caña de Cerveza o Copa de Vino',
    description: 'Canjea por una caña bien fría o una copa de vino de la casa.',
    cost_points: 500,
    stock: 45,
    active: true,
    category: 'consumicion',
    image_emoji: '🍺',
    created_at: '2025-01-01T00:00:00.000Z',
  },
  {
    id: 2,
    name: 'Empanada Criolla Fulano (Artesanal)',
    description: 'Cualquiera de nuestras 13 variedades de empanadas argentinas artesanas recién horneadas.',
    cost_points: 720,
    stock: 50,
    active: true,
    category: 'consumicion',
    image_emoji: '🥟',
    created_at: '2025-01-01T00:00:00.000Z',
  },
  {
    id: 3,
    name: 'Ración de Croquetas Caseras',
    description: '6 unidades de nuestras famosas croquetas de jamón de bellota.',
    cost_points: 1550,
    stock: 25,
    active: true,
    category: 'consumicion',
    image_emoji: '🥟',
    created_at: '2025-01-01T00:00:00.000Z',
  },
  {
    id: 4,
    name: 'Cóctel Especial del Bartender',
    description: 'Cualquier cóctel clásico o de autor de nuestra carta de noche.',
    cost_points: 2000,
    stock: 20,
    active: true,
    category: 'consumicion',
    image_emoji: '🍸',
    created_at: '2025-01-01T00:00:00.000Z',
  },
  {
    id: 5,
    name: 'Hamburguesa Ibérica Fulano',
    description: 'Hamburguesa completa con patatas y salsa especial de la casa.',
    cost_points: 2650,
    stock: 15,
    active: true,
    category: 'consumicion',
    image_emoji: '🍔',
    created_at: '2025-01-01T00:00:00.000Z',
  },
  {
    id: 6,
    name: 'Camiseta Exclusiva Fulano Madrid',
    description: 'Camiseta de algodón orgánico serigrafiada edición limitada.',
    cost_points: 3500,
    stock: 10,
    active: true,
    category: 'merchandising',
    image_emoji: '👕',
    created_at: '2025-01-01T00:00:00.000Z',
  },
  {
    id: 7,
    name: 'Cena Degustación para 2 Personas',
    description: 'Menú completo de 4 pases con maridaje de vinos y cócteles.',
    cost_points: 13600,
    stock: 4,
    active: true,
    category: 'experiencia',
    image_emoji: '✨',
    created_at: '2025-01-01T00:00:00.000Z',
  },
];

export const DEFAULT_MENU: MenuItem[] = [
  { id: 1, name: 'Caña Mahou 5 Estrellas', category: 'bebida', price: 2.5, description: 'Cerveza rubia de grifo clásica madrileña, fresca y bien tirada.', image_emoji: '🍺', is_active: true },
  { id: 2, name: 'Doble Artesanal IPA Madrileña', category: 'bebida', price: 3.9, description: 'Cerveza artesanal de lúpulo aromático y cuerpo dorado.', image_emoji: '🍻', is_active: true },
  { id: 3, name: 'Refresco / Agua de Manantial', category: 'bebida', price: 2.7, description: 'Botella de agua mineral de Solán o refrescos premium.', image_emoji: '🥤', is_active: true },
  { id: 4, name: 'Café de Especialidad Arábica', category: 'bebida', price: 2.0, description: 'Café recién molido de tueste natural con leche fresca o vegetal.', image_emoji: '☕', is_active: true },
  { id: 5, name: 'Cóctel Mojito Clásico', category: 'bebida_coctel', price: 8.5, description: 'Ron añejo, hierbabuena fresca, lima natural y azúcar de caña.', image_emoji: '🍹', is_active: true },
  { id: 6, name: 'Cóctel Fulano Aperol Spritz', category: 'bebida_coctel', price: 8.0, description: 'Aperol, cava brut reserva, soda y rodaja de naranja sanguina.', image_emoji: '🥂', is_active: true },
  { id: 7, name: 'Gin Tonic Premium Fulano', category: 'bebida_coctel', price: 10.5, description: 'Ginebra botánica premium con tónica Fever-Tree y enebro.', image_emoji: '🍸', is_active: true },
  { id: 8, name: 'Patatas Bravas Ahumadas Fulano', category: 'plato', price: 6.8, description: 'Patata agria crujiente con salsa brava casera y alioli de ajo asado.', image_emoji: '🍟', is_active: true },
  { id: 9, name: 'Sándwich Brioche Pastrami New York', category: 'plato', price: 9.5, description: 'Pan brioche tostado con pastrami curado, pepinillos y mostaza dulce.', image_emoji: '🥪', is_active: true },
  { id: 10, name: 'Hamburguesa Ibérica Fulano Gourmet', category: 'plato', price: 13.9, description: '200g de carne madurada, queso manchego curado y cebolla caramelizada.', image_emoji: '🍔', is_active: true },
  { id: 11, name: 'Tarta de Queso Fluida Estilo Madrid', category: 'postre', price: 5.8, description: 'Horneada al momento con corazón cremoso y base de galleta artesana.', image_emoji: '🍰', is_active: true },
  { id: 12, name: 'Coulant de Chocolate Belga 70%', category: 'postre', price: 6.2, description: 'Bizcocho tibio de cacao puro con helado artesano de vainilla Bourbon.', image_emoji: '🍨', is_active: true },
];

interface LocalStorageData {
  config: SystemConfig;
  users: User[];
  rewards: Reward[];
  menu: MenuItem[];
  transactions: Transaction[];
  redemptions: Redemption[];
  coupons: Coupon[];
  bdpOrders: BdpOrder[];
  claimedTickets: ClaimedTicket[];
  adjustments: PointAdjustment[];
}

const STORAGE_KEY = 'fidelityful_app_state_v1';

class MockStore {
  private data: LocalStorageData;

  constructor() {
    this.data = this.loadState();
  }

  private loadState(): LocalStorageData {
    if (typeof window === 'undefined') {
      return {
        config: { ...DEFAULT_CONFIG },
        users: [...DEFAULT_USERS],
        rewards: [...DEFAULT_REWARDS],
        menu: [...DEFAULT_MENU],
        transactions: [],
        redemptions: [],
        coupons: [],
        bdpOrders: [],
        claimedTickets: [],
        adjustments: [],
      };
    }

    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          config: parsed.config || { ...DEFAULT_CONFIG },
          users: parsed.users?.length ? parsed.users : [...DEFAULT_USERS],
          rewards: parsed.rewards?.length ? parsed.rewards : [...DEFAULT_REWARDS],
          menu: parsed.menu?.length ? parsed.menu : [...DEFAULT_MENU],
          transactions: parsed.transactions || [],
          redemptions: parsed.redemptions || [],
          coupons: parsed.coupons || [],
          bdpOrders: parsed.bdpOrders || [],
          claimedTickets: parsed.claimedTickets || [],
          adjustments: parsed.adjustments || [],
        };
      }
    } catch (_e) {
      // ignore
    }

    const initial: LocalStorageData = {
      config: { ...DEFAULT_CONFIG },
      users: [...DEFAULT_USERS],
      rewards: [...DEFAULT_REWARDS],
      menu: [...DEFAULT_MENU],
      transactions: [],
      redemptions: [],
      coupons: [],
      bdpOrders: [],
      claimedTickets: [],
      adjustments: [],
    };
    this.saveState(initial);
    return initial;
  }

  private saveState(data?: LocalStorageData) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data || this.data));
    } catch (_e) {
      // ignore
    }
  }

  getConfig(): SystemConfig {
    return { ...this.data.config };
  }

  updateConfig(patch: Partial<SystemConfig>): SystemConfig {
    this.data.config = {
      ...this.data.config,
      ...patch,
      updated_at: new Date().toISOString(),
    };
    this.saveState();
    return { ...this.data.config };
  }

  getUsers(role?: string, search?: string): User[] {
    let list = [...this.data.users];
    if (role) {
      list = list.filter((u) => u.role === role);
    }
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(
        (u) =>
          u.name.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q) ||
          (u.phone && u.phone.includes(q)) ||
          u.uid.toLowerCase().includes(q)
      );
    }
    return list;
  }

  getUserDetails(idOrUid: number | string): UserDetailsResponse {
    const user = this.data.users.find(
      (u) => u.id === Number(idOrUid) || u.uid === String(idOrUid)
    );
    if (!user) {
      throw new Error('Usuario no encontrado');
    }
    const userTransactions = this.data.transactions.filter((t) => t.user_id === user.id);
    const userRedemptions = this.data.redemptions
      .filter((r) => r.user_id === user.id)
      .map((r) => {
        const rew = this.data.rewards.find((rw) => rw.id === r.reward_id);
        return {
          ...r,
          reward_name: rew?.name || 'Recompensa',
          reward_category: rew?.category || 'consumicion',
          image_emoji: rew?.image_emoji || '🎁',
        };
      });
    const userCoupons = this.data.coupons.filter((c) => c.user_id === user.id);
    const userAdjustments = this.data.adjustments.filter((a) => a.user_id === user.id);

    return {
      user: { ...user },
      transactions: userTransactions,
      redemptions: userRedemptions,
      coupons: userCoupons,
      adjustments: userAdjustments,
      levelDetails: {
        currentLevel: user.level,
        bonusPct: user.level === 'VIP' ? 20 : user.level === 'Oro' ? 10 : user.level === 'Plata' ? 5 : 0,
        nextLevel: user.level === 'Bronce' ? 'Plata' : user.level === 'Plata' ? 'Oro' : user.level === 'Oro' ? 'VIP' : 'Máximo (VIP)',
        pointsToNext: Math.max(0, (user.level === 'Bronce' ? 1000 : user.level === 'Plata' ? 3000 : 7000) - user.points),
        nextThreshold: user.level === 'Bronce' ? 1000 : user.level === 'Plata' ? 3000 : 7000,
        progressPct: Math.min(100, Math.round((user.points / (user.level === 'Bronce' ? 1000 : user.level === 'Plata' ? 3000 : 7000)) * 100)),
      },
    };
  }

  createUser(data: { name: string; email: string; phone?: string; birthday?: string }): User {
    const existing = this.data.users.find((u) => u.email.toLowerCase() === data.email.toLowerCase());
    if (existing) {
      throw new Error('Ya existe un usuario con este correo electrónico');
    }

    const nextId = Math.max(...this.data.users.map((u) => u.id), 0) + 1;
    const uid = `USR-CLI-${Date.now().toString().slice(-4)}${Math.floor(10 + Math.random() * 90)}`;
    const avatarUrl = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(data.name)}`;

    const newUser: User = {
      id: nextId,
      uid,
      name: data.name,
      email: data.email.toLowerCase(),
      phone: data.phone || undefined,
      birthday: data.birthday || undefined,
      points: 0,
      total_spent: 0,
      total_visits: 0,
      level: 'Bronce',
      role: 'client',
      avatar_url: avatarUrl,
      created_at: new Date().toISOString(),
      last_activity_at: new Date().toISOString(),
    };

    this.data.users.push(newUser);
    this.saveState();
    return { ...newUser };
  }

  updateUserRole(userId: number, role: string): User {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) throw new Error('Usuario no encontrado');
    user.role = role as any;
    user.last_activity_at = new Date().toISOString();
    this.saveState();
    return { ...user };
  }

  saveUserBirthday(userId: number, birthday: string): { success: boolean; message: string; user: User } {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) throw new Error('Usuario no encontrado');
    user.birthday = birthday;
    user.last_activity_at = new Date().toISOString();
    this.saveState();
    return { success: true, message: 'Cumpleaños registrado', user: { ...user } };
  }

  claimBirthdayBonus(userId: number): { success: boolean; bonusPoints: number; message: string; user: User } {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) throw new Error('Usuario no encontrado');
    const bonus = this.data.config.birthday_bonus_points || 150;
    user.points += bonus;
    user.birthday_bonus_year = new Date().getFullYear();
    user.last_activity_at = new Date().toISOString();
    this.saveState();
    return {
      success: true,
      bonusPoints: bonus,
      message: `¡Feliz cumpleaños! Se han acreditado +${bonus} puntos a tu cuenta.`,
      user: { ...user },
    };
  }

  updateUserProfile(userId: number, patch: { name?: string; email?: string; phone?: string; birthday?: string }): User {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) throw new Error('Usuario no encontrado');
    if (patch.name) user.name = patch.name;
    if (patch.email) user.email = patch.email.toLowerCase();
    if (patch.phone !== undefined) user.phone = patch.phone;
    if (patch.birthday !== undefined) user.birthday = patch.birthday;
    user.last_activity_at = new Date().toISOString();
    this.saveState();
    return { ...user };
  }

  getMenu(): MenuItem[] {
    return [...this.data.menu];
  }

  registerConsumption(data: {
    userId: number;
    items: Array<{ id: number; name: string; category: string; price: number; quantity: number }>;
    staffName?: string;
    notes?: string;
  }) {
    const user = this.data.users.find((u) => u.id === data.userId);
    if (!user) throw new Error('Usuario no encontrado');

    const totalEuros = data.items.reduce((sum, item) => sum + item.price * item.quantity, 0);

    const transactionItems: TransactionItem[] = data.items.map((it) => {
      let mult = 1.0;
      if (it.category === 'bebida_coctel') mult = Number(this.data.config.multiplier_coctel) || 1.5;
      else if (it.category === 'plato') mult = Number(this.data.config.multiplier_plato) || 2.0;
      else if (it.category === 'postre') mult = Number(this.data.config.multiplier_postre) || 1.2;
      else mult = Number(this.data.config.multiplier_bebida) || 1.0;
      const subtotal = it.price * it.quantity;
      const points = Math.round(subtotal * this.data.config.euro_to_points * mult);
      return {
        id: it.id,
        name: it.name,
        category: it.category,
        price: it.price,
        quantity: it.quantity,
        multiplier: mult,
        subtotal,
        points,
      };
    });

    const basePts = transactionItems.reduce((s, it) => s + it.points, 0);

    let bonusPct = 0;
    if (user.level === 'VIP') bonusPct = this.data.config.level_vip_bonus_pct;
    else if (user.level === 'Oro') bonusPct = this.data.config.level_oro_bonus_pct;
    else if (user.level === 'Plata') bonusPct = this.data.config.level_plata_bonus_pct;

    const totalPointsEarned = Math.round(basePts * (1 + bonusPct / 100));

    user.points += totalPointsEarned;
    user.total_spent = Number((Number(user.total_spent) + totalEuros).toFixed(2));
    user.total_visits += 1;
    user.last_activity_at = new Date().toISOString();

    // Check level upgrade
    if (user.points >= this.data.config.level_vip_threshold) user.level = 'VIP';
    else if (user.points >= this.data.config.level_oro_threshold) user.level = 'Oro';
    else if (user.points >= this.data.config.level_plata_threshold) user.level = 'Plata';

    const txCode = `TX-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
    const tx: Transaction = {
      id: this.data.transactions.length + 1,
      transaction_code: txCode,
      user_id: user.id,
      staff_name: data.staffName || 'Barra Fulano',
      items: transactionItems,
      total_euros: totalEuros,
      base_points: basePts,
      level_bonus_pct: bonusPct,
      points_earned: totalPointsEarned,
      notes: data.notes || '',
      created_at: new Date().toISOString(),
      user_name: user.name,
      user_level: user.level,
    };
    this.data.transactions.unshift(tx);
    this.saveState();

    return {
      success: true,
      transaction: tx,
      user: { ...user },
      pointsEarned: totalPointsEarned,
    };
  }

  getRewards(): Reward[] {
    return [...this.data.rewards];
  }

  createReward(data: Partial<Reward>): Reward {
    const nextId = Math.max(...this.data.rewards.map((r) => r.id), 0) + 1;
    const rew: Reward = {
      id: nextId,
      name: data.name || 'Nueva Recompensa',
      description: data.description || '',
      cost_points: Number(data.cost_points) || 500,
      stock: data.stock !== undefined ? Number(data.stock) : 20,
      active: data.active !== undefined ? Boolean(data.active) : true,
      category: data.category || 'consumicion',
      image_emoji: data.image_emoji || '🎁',
      created_at: new Date().toISOString(),
    };
    this.data.rewards.push(rew);
    this.saveState();
    return { ...rew };
  }

  updateReward(id: number, patch: Partial<Reward>): Reward {
    const rew = this.data.rewards.find((r) => r.id === id);
    if (!rew) throw new Error('Recompensa no encontrada');
    Object.assign(rew, patch);
    this.saveState();
    return { ...rew };
  }

  toggleRewardActive(id: number) {
    const rew = this.data.rewards.find((r) => r.id === id);
    if (!rew) throw new Error('Recompensa no encontrada');
    rew.active = !rew.active;
    this.saveState();
    return { success: true, reward: { ...rew } };
  }

  deleteRewardPermanent(id: number) {
    this.data.rewards = this.data.rewards.filter((r) => r.id !== id);
    this.saveState();
    return { success: true };
  }

  redeemReward(userId: number, rewardId: number) {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) throw new Error('Usuario no encontrado');
    const reward = this.data.rewards.find((r) => r.id === rewardId);
    if (!reward) throw new Error('Recompensa no encontrada');

    if (user.points < reward.cost_points) {
      throw new Error(`Puntos insuficientes. Necesitas ${reward.cost_points} pts y tienes ${user.points} pts.`);
    }

    user.points -= reward.cost_points;
    user.last_activity_at = new Date().toISOString();
    if (reward.stock > 0) reward.stock -= 1;

    const rdmCode = `RDM-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
    const redemption: Redemption = {
      id: this.data.redemptions.length + 1,
      redemption_code: rdmCode,
      user_id: user.id,
      reward_id: reward.id,
      points_used: reward.cost_points,
      status: 'active',
      claimed_at: undefined,
      created_at: new Date().toISOString(),
      reward_name: reward.name,
      reward_description: reward.description,
      image_emoji: reward.image_emoji,
      user_name: user.name,
      user_email: user.email,
    };
    this.data.redemptions.unshift(redemption);
    this.saveState();

    return {
      success: true,
      redemption,
      user: { ...user },
      reward: { ...reward },
    };
  }

  getRedemptions(): Redemption[] {
    return this.data.redemptions.map((r) => {
      const rew = this.data.rewards.find((rw) => rw.id === r.reward_id);
      return {
        ...r,
        reward_name: rew?.name || 'Recompensa',
        reward_category: rew?.category || 'consumicion',
        image_emoji: rew?.image_emoji || '🎁',
      };
    });
  }

  claimRedemptionInBar(code: string) {
    const rdm = this.data.redemptions.find((r) => r.redemption_code.toUpperCase() === code.trim().toUpperCase());
    if (!rdm) throw new Error('Código de canje no encontrado');
    if (rdm.status === 'claimed') throw new Error('Este vale ya ha sido canjeado anteriormente');
    rdm.status = 'claimed';
    rdm.claimed_at = new Date().toISOString();
    this.saveState();
    const rew = this.data.rewards.find((rw) => rw.id === rdm.reward_id);
    const user = this.data.users.find((u) => u.id === rdm.user_id);
    return {
      success: true,
      redemption: rdm,
      reward: rew,
      user,
      message: `Vale validado con éxito: ${rew?.name || 'Recompensa'} entregado`,
    };
  }

  redeemCouponInBar(code: string) {
    const cpn = this.data.coupons.find((c) => c.code.toUpperCase() === code.trim().toUpperCase());
    if (!cpn) throw new Error('Cupón no encontrado');
    if (cpn.is_used) throw new Error('Este cupón ya ha sido utilizado');
    cpn.is_used = true;
    cpn.used_at = new Date().toISOString();
    this.saveState();
    return {
      success: true,
      coupon: cpn,
      message: `Cupón ${cpn.code} canjeado con éxito: ${cpn.title}`,
    };
  }

  adjustPoints(userId: number, amount: number, reason: string) {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) throw new Error('Usuario no encontrado');
    user.points += amount;
    if (user.points < 0) user.points = 0;
    user.last_activity_at = new Date().toISOString();

    const adj: PointAdjustment = {
      id: this.data.adjustments.length + 1,
      user_id: user.id,
      amount,
      reason,
      created_at: new Date().toISOString(),
    };
    this.data.adjustments.unshift(adj);
    this.saveState();

    return {
      success: true,
      user: { ...user },
      message: `Puntos ajustados (${amount >= 0 ? '+' : ''}${amount} pts). Razón: ${reason}`,
    };
  }

  getAnalytics(): AnalyticsData {
    const clients = this.data.users.filter((u) => u.role === 'client');
    const totalPoints = clients.reduce((sum, u) => sum + (u.points || 0), 0);
    const totalRevenue = this.data.transactions.reduce((sum, t) => sum + (Number(t.total_euros) || 0), 0);
    const totalVisits = this.data.transactions.length;

    return {
      users: {
        total_users: this.data.users.length,
        total_clients: clients.length,
        bronce_count: clients.filter((u) => u.level === 'Bronce').length,
        plata_count: clients.filter((u) => u.level === 'Plata').length,
        oro_count: clients.filter((u) => u.level === 'Oro').length,
        vip_count: clients.filter((u) => u.level === 'VIP').length,
        points_in_circulation: totalPoints,
        total_revenue: totalRevenue,
        total_visits: totalVisits,
      },
      transactions: {
        tx_count: this.data.transactions.length,
        total_billed: totalRevenue,
        total_points_earned: this.data.transactions.reduce((s, t) => s + t.points_earned, 0),
        avg_ticket: this.data.transactions.length ? (totalRevenue / this.data.transactions.length).toFixed(2) : 0,
      },
      redemptions: {
        redemptions_count: this.data.redemptions.length,
        claimed_count: this.data.redemptions.filter((r) => r.status === 'claimed').length,
        total_points_redeemed: this.data.redemptions.reduce((s, r) => s + r.points_used, 0),
      },
      topClients: [...clients].sort((a, b) => b.points - a.points).slice(0, 5),
      topRewards: this.data.rewards.slice(0, 4).map((r) => ({
        id: r.id,
        name: r.name,
        cost_points: r.cost_points,
        image_emoji: r.image_emoji,
        redemption_count: this.data.redemptions.filter((rd) => rd.reward_id === r.id).length,
      })),
      recentTransactions: this.data.transactions.slice(0, 10),
    };
  }

  createBdpOrder(data: {
    userId: number;
    tableNumber?: string;
    items: Array<{ name: string; quantity: number; category?: string; price: number }>;
    terraceService?: boolean;
    paymentMethod?: string;
  }) {
    const user = this.data.users.find((u) => u.id === data.userId);
    if (!user) throw new Error('Usuario no encontrado');

    const totalAmount = data.items.reduce((s, it) => s + it.price * it.quantity, 0);
    const orderCode = `BDP-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;

    const bdpItems: BdpOrderItem[] = data.items.map((it) => ({
      name: it.name,
      quantity: it.quantity,
      category: it.category || 'general',
      unit_price: it.price,
      subtotal: it.price * it.quantity,
    }));

    const method: 'tpv_qr' | 'tarjeta' | 'bizum' =
      data.paymentMethod === 'tarjeta' || data.paymentMethod === 'bizum' ? data.paymentMethod : 'tpv_qr';

    const order: BdpOrder = {
      id: this.data.bdpOrders.length + 1,
      order_code: orderCode,
      user_id: user.id,
      user_name: user.name,
      user_email: user.email,
      table_number: data.tableNumber || 'Mesa 4',
      total_amount: totalAmount,
      terrace_service: Boolean(data.terraceService),
      discount_amount: 0,
      status: 'pending',
      payment_method: method,
      items: bdpItems,
      points_preview: Math.round(totalAmount * (this.data.config.euro_to_points || 10)),
      created_at: new Date().toISOString(),
    };

    this.data.bdpOrders.unshift(order);
    this.saveState();
    return { success: true, order, message: 'Orden BDP generada con éxito' };
  }

  getBdpOrders(): BdpOrder[] {
    return [...this.data.bdpOrders];
  }

  getBdpOrder(orderCode: string): BdpOrder {
    const o = this.data.bdpOrders.find((ord) => ord.order_code === orderCode);
    if (!o) throw new Error('Orden BDP no encontrada');
    return { ...o };
  }

  simulateBdpPayment(orderCode: string, paymentMethod?: string) {
    const order = this.data.bdpOrders.find((ord) => ord.order_code === orderCode);
    if (!order) throw new Error('Orden BDP no encontrada');
    order.status = 'paid';
    order.paid_at = new Date().toISOString();
    if (paymentMethod === 'tarjeta' || paymentMethod === 'bizum' || paymentMethod === 'tpv_qr') {
      order.payment_method = paymentMethod;
    }

    const user = this.data.users.find((u) => u.id === order.user_id);
    let ptsEarned = 0;
    if (user) {
      ptsEarned = order.points_preview || Math.round(order.total_amount * 10);
      user.points += ptsEarned;
      user.total_spent = Number((Number(user.total_spent) + order.total_amount).toFixed(2));
      user.total_visits += 1;
      user.last_activity_at = new Date().toISOString();
    }

    this.saveState();
    return {
      success: true,
      message: `Pago de comanda ${orderCode} confirmado correctamente vía pasarela BDP`,
      order: { ...order },
      pointsAwarded: ptsEarned,
      user: user ? { ...user } : undefined,
    };
  }

  claimBdpTicketDirectly(data: {
    ticket_id: string;
    amount: number;
    date_str?: string;
    items_detected?: string[];
    userId: number;
  }): ClaimTicketResult {
    const existing = this.data.claimedTickets.find((t) => t.ticket_id === data.ticket_id);
    if (existing) {
      return {
        success: false,
        ticket_id: data.ticket_id,
        amount: data.amount,
        points_awarded: 0,
        multiplier: 1.0,
        newPoints: 0,
        userLevel: 'Bronce',
        levelUpgraded: false,
        alreadyClaimed: true,
        message: 'Este ticket ya ha sido reclamado anteriormente',
      };
    }

    const user = this.data.users.find((u) => u.id === data.userId);
    if (!user) {
      return {
        success: false,
        ticket_id: data.ticket_id,
        amount: data.amount,
        points_awarded: 0,
        multiplier: 1.0,
        newPoints: 0,
        userLevel: 'Bronce',
        levelUpgraded: false,
        message: 'Usuario no encontrado',
      };
    }

    const ptsAwarded = Math.round(data.amount * 10);
    user.points += ptsAwarded;
    user.total_spent = Number((Number(user.total_spent) + data.amount).toFixed(2));
    user.total_visits += 1;
    user.last_activity_at = new Date().toISOString();

    const claim: ClaimedTicket = {
      id: this.data.claimedTickets.length + 1,
      ticket_id: data.ticket_id,
      user_id: user.id,
      user_name: user.name,
      user_email: user.email,
      amount: data.amount,
      date_str: data.date_str || new Date().toISOString(),
      items_detected: data.items_detected || [],
      points_awarded: ptsAwarded,
      multiplier: 1.0,
      source: 'gemini_ai',
      claimed_at: new Date().toISOString(),
    };
    this.data.claimedTickets.unshift(claim);
    this.saveState();

    return {
      success: true,
      ticket_id: data.ticket_id,
      amount: data.amount,
      points_awarded: ptsAwarded,
      multiplier: 1.0,
      newPoints: user.points,
      userLevel: user.level,
      levelUpgraded: false,
      message: `Ticket validado con éxito. Se han añadido +${ptsAwarded} puntos a tu cuenta.`,
    };
  }

  getClaimedTickets(): ClaimedTicket[] {
    return [...this.data.claimedTickets];
  }

  syncOAuthUser(data: { email: string; name?: string; avatar_url?: string; phone?: string }) {
    let user = this.data.users.find((u) => u.email.toLowerCase() === data.email.toLowerCase());
    let isNew = false;
    if (!user) {
      isNew = true;
      user = this.createUser({
        name: data.name || data.email.split('@')[0],
        email: data.email,
        phone: data.phone,
      });
      if (data.avatar_url) user.avatar_url = data.avatar_url;
      this.saveState();
    }
    return { success: true, user: { ...user }, isNew, message: 'Usuario sincronizado' };
  }

  resetTestData() {
    this.data.transactions = [];
    this.data.redemptions = [];
    this.data.bdpOrders = [];
    this.data.claimedTickets = [];
    this.data.coupons = [];
    this.data.adjustments = [];
    this.data.users = [...DEFAULT_USERS];
    this.data.rewards = [...DEFAULT_REWARDS];
    this.data.config = { ...DEFAULT_CONFIG };
    this.saveState();
    return { success: true, message: 'Datos de prueba purgados a estado cero' };
  }
}

export const mockStore = new MockStore();
