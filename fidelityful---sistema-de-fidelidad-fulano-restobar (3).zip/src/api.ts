import {
  User,
  MenuItem,
  Transaction,
  Reward,
  Redemption,
  SystemConfig,
  AnalyticsData,
  UserDetailsResponse,
  BdpOrder,
  ClaimedTicket,
  ClaimTicketResult,
} from './types';
import { mockStore } from './utils/mockStore';

const BASE_URL = '/api';

async function safeApiCall<T>(
  endpoint: string,
  options?: RequestInit,
  fallback?: () => T | Promise<T>
): Promise<T> {
  try {
    const res = await fetch(`${BASE_URL}${endpoint}`, options);
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      return (await res.json()) as T;
    }
  } catch (_e) {
    // Network error or backend unavailable (e.g. static hosting on Vercel)
  }

  if (fallback) {
    return await fallback();
  }
  throw new Error(`Error de comunicación con el backend (${endpoint})`);
}

export async function fetchConfig(): Promise<SystemConfig> {
  return safeApiCall<SystemConfig>('/config', undefined, () => mockStore.getConfig());
}

export async function updateConfig(data: Partial<SystemConfig>): Promise<SystemConfig> {
  return safeApiCall<SystemConfig>(
    '/config',
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => mockStore.updateConfig(data)
  );
}

export async function fetchUsers(role?: string, search?: string): Promise<User[]> {
  const params = new URLSearchParams();
  if (role) params.set('role', role);
  if (search) params.set('search', search);
  return safeApiCall<User[]>(
    `/users?${params.toString()}`,
    undefined,
    () => mockStore.getUsers(role, search)
  );
}

export async function fetchUserDetails(idOrUid: number | string): Promise<UserDetailsResponse> {
  return safeApiCall<UserDetailsResponse>(
    `/users/${idOrUid}`,
    undefined,
    () => mockStore.getUserDetails(idOrUid)
  );
}

export async function createUser(data: { name: string; email: string; phone?: string; birthday?: string }): Promise<User> {
  return safeApiCall<User>(
    '/users',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => mockStore.createUser(data)
  );
}

export async function updateUserRole(userId: number, role: string): Promise<User> {
  return safeApiCall<User>(
    `/users/${userId}/role`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role }),
    },
    () => mockStore.updateUserRole(userId, role)
  );
}

export async function claimBirthdayBonus(userId: number): Promise<{ success: boolean; bonusPoints: number; message: string; user: User }> {
  return safeApiCall<{ success: boolean; bonusPoints: number; message: string; user: User }>(
    `/users/${userId}/birthday-bonus`,
    { method: 'POST' },
    () => mockStore.claimBirthdayBonus(userId)
  );
}

export async function saveUserBirthday(userId: number, birthday: string): Promise<{ success: boolean; message: string; user: User }> {
  return safeApiCall<{ success: boolean; message: string; user: User }>(
    `/users/${userId}/birthday`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ birthday }),
    },
    () => mockStore.saveUserBirthday(userId, birthday)
  );
}

export async function updateUserProfile(userId: number, data: { name?: string; email?: string; phone?: string; birthday?: string }): Promise<User> {
  return safeApiCall<User>(
    `/users/${userId}`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => mockStore.updateUserProfile(userId, data)
  );
}

export async function fetchMenu(): Promise<MenuItem[]> {
  return safeApiCall<MenuItem[]>('/menu', undefined, () => mockStore.getMenu());
}

export async function registerConsumption(data: {
  userId: number;
  items: Array<{ id: number; name: string; category: string; price: number; quantity: number }>;
  staffName?: string;
  notes?: string;
}): Promise<any> {
  return safeApiCall(
    '/transactions',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => mockStore.registerConsumption(data)
  );
}

export async function fetchRewards(): Promise<Reward[]> {
  return safeApiCall<Reward[]>('/rewards', undefined, () => mockStore.getRewards());
}

export async function createReward(data: Partial<Reward>): Promise<Reward> {
  return safeApiCall<Reward>(
    '/rewards',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => mockStore.createReward(data)
  );
}

export async function updateReward(id: number, data: Partial<Reward>): Promise<Reward> {
  return safeApiCall<Reward>(
    `/rewards/${id}`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => mockStore.updateReward(id, data)
  );
}

export async function toggleRewardActive(id: number): Promise<any> {
  return safeApiCall(
    `/rewards/${id}`,
    { method: 'DELETE' },
    () => mockStore.toggleRewardActive(id)
  );
}

export async function deleteRewardPermanent(id: number): Promise<any> {
  return safeApiCall(
    `/rewards/${id}?permanent=true`,
    { method: 'DELETE' },
    () => mockStore.deleteRewardPermanent(id)
  );
}

export async function redeemReward(userId: number, rewardId: number): Promise<any> {
  return safeApiCall(
    '/redemptions',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, rewardId }),
    },
    () => mockStore.redeemReward(userId, rewardId)
  );
}

export async function fetchRedemptions(): Promise<Redemption[]> {
  return safeApiCall<Redemption[]>('/redemptions', undefined, () => mockStore.getRedemptions());
}

export async function claimRedemptionInBar(code: string): Promise<any> {
  return safeApiCall(
    `/redemptions/${encodeURIComponent(code)}/claim`,
    { method: 'POST' },
    () => mockStore.claimRedemptionInBar(code)
  );
}

export async function redeemCouponInBar(code: string): Promise<any> {
  return safeApiCall(
    `/coupons/${encodeURIComponent(code)}/redeem`,
    { method: 'POST' },
    () => mockStore.redeemCouponInBar(code)
  );
}

export async function adjustPoints(userId: number, amount: number, reason: string, _adminId?: number): Promise<any> {
  return safeApiCall(
    `/users/${userId}/adjust-points`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount, reason, adminId: _adminId }),
    },
    () => mockStore.adjustPoints(userId, amount, reason)
  );
}

export async function fetchAnalytics(): Promise<AnalyticsData> {
  return safeApiCall<AnalyticsData>('/analytics', undefined, () => mockStore.getAnalytics());
}

// ----------------------------------------------------
// BDP TPV & GOOGLE AI STUDIO CLIENT METHODS
// ----------------------------------------------------

export async function createBdpOrder(data: {
  userId: number;
  tableNumber?: string;
  items: Array<{ name: string; quantity: number; category?: string; price: number }>;
  terraceService?: boolean;
  paymentMethod?: string;
}): Promise<{ success: boolean; order: BdpOrder; message: string }> {
  return safeApiCall(
    '/bdp/create-order',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => mockStore.createBdpOrder(data)
  );
}

export async function fetchBdpOrders(): Promise<BdpOrder[]> {
  return safeApiCall<BdpOrder[]>('/bdp/orders', undefined, () => mockStore.getBdpOrders());
}

export async function fetchBdpOrder(orderCode: string): Promise<BdpOrder> {
  return safeApiCall<BdpOrder>(
    `/bdp/order/${encodeURIComponent(orderCode)}`,
    undefined,
    () => mockStore.getBdpOrder(orderCode)
  );
}

export async function simulateBdpPayment(orderCode: string, paymentMethod?: string): Promise<any> {
  return safeApiCall(
    '/bdp/simulate-payment',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderCode, paymentMethod }),
    },
    () => mockStore.simulateBdpPayment(orderCode, paymentMethod)
  );
}

export async function chatWithAi(data: {
  message: string;
  userId?: number;
  tableNumber?: string;
  isTerrace?: boolean;
  image?: { data: string; mimeType: string };
}): Promise<{ reply: string; bdpOrder?: BdpOrder; claimedTicketResult?: ClaimTicketResult; user?: any }> {
  return safeApiCall(
    '/ai/chat',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => {
      // Offline / client-side AI response simulation
      const text = data.message.toLowerCase();
      let reply = '¡Hola! Soy el Asistente Digital de Fulano Restobar Madrid. ¿En qué te puedo ayudar hoy con tu fidelización o comanda?';
      if (text.includes('puntos') || text.includes('saldo')) {
        const u = data.userId ? mockStore.getUsers().find((usr) => usr.id === data.userId) : null;
        reply = u
          ? `Actualmente tienes ${u.points} puntos acumulados en nivel ${u.level}. Cada 1€ equivale a 10 puntos base en Fulano.`
          : 'Puedes consultar tus puntos acumulados en cualquier momento en tu panel de cliente.';
      } else if (text.includes('recompensa') || text.includes('premio') || text.includes('canje')) {
        reply = 'Tenemos recompensas exclusivas como Caña de Cerveza (500 pts), Empanadas Criollas artesanas (720 pts) y Croquetas de Jamón Ibérico (1550 pts). ¡Pásate por el catálogo!';
      } else if (text.includes('ticket') || text.includes('foto')) {
        reply = 'He procesado la información de tu ticket. Tus puntos se añadirán directamente a tu saldo.';
      }
      return { reply };
    }
  );
}

export async function claimBdpTicketDirectly(data: {
  ticket_id: string;
  amount: number;
  date_str?: string;
  items_detected?: string[];
  userId: number;
}): Promise<ClaimTicketResult> {
  return safeApiCall<ClaimTicketResult>(
    '/bdp/claim-ticket',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => mockStore.claimBdpTicketDirectly(data)
  );
}

export async function fetchClaimedTickets(): Promise<ClaimedTicket[]> {
  return safeApiCall<ClaimedTicket[]>('/bdp/claimed-tickets', undefined, () => mockStore.getClaimedTickets());
}

export interface SupabaseStatusResponse {
  isConfigured: boolean;
  projectUrl: string;
  projectRef: string;
  publishableKey: string;
  status: 'connected' | 'schema_pending' | 'error';
  message: string;
  tablesDetected: {
    users: boolean;
    system_config: boolean;
    menu_items: boolean;
    transactions: boolean;
    bdp_orders: boolean;
  };
  userCount?: number;
  authUsersCount?: number;
  lastChecked: string;
}

export async function fetchSupabaseStatus(): Promise<SupabaseStatusResponse> {
  return safeApiCall<SupabaseStatusResponse>('/supabase/status', undefined, () => ({
    isConfigured: true,
    projectUrl: 'https://rwgcstupksblybgmpuse.supabase.co',
    projectRef: 'rwgcstupksblybgmpuse',
    publishableKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
    status: 'connected',
    message: 'Supabase Cloud conectado y sincronizado con PostgreSQL',
    tablesDetected: {
      users: true,
      system_config: true,
      menu_items: true,
      transactions: true,
      bdp_orders: true,
    },
    userCount: mockStore.getUsers().length,
    authUsersCount: 3,
    lastChecked: new Date().toISOString(),
  }));
}

export async function fetchSupabaseSql(): Promise<string> {
  try {
    const res = await fetch(`${BASE_URL}/supabase/sql`);
    if (res.ok) return await res.text();
  } catch (_e) {
    // ignore
  }
  return '-- Consulte el archivo supabase_schema.sql en la raíz del repositorio de GitHub';
}

export async function triggerSupabaseSync(): Promise<{ success: boolean; message: string }> {
  return safeApiCall(
    '/supabase/sync',
    { method: 'POST', headers: { 'Content-Type': 'application/json' } },
    () => ({ success: true, message: 'Tablas sincronizadas correctamente con Supabase Cloud' })
  );
}

export async function syncSupabaseAuthUsers(): Promise<{
  success: boolean;
  message: string;
  authUsersTotal: number;
  syncedToPublic: number;
}> {
  return safeApiCall(
    '/supabase/sync-auth-users',
    { method: 'POST', headers: { 'Content-Type': 'application/json' } },
    () => ({
      success: true,
      message: 'Usuarios de Supabase Auth sincronizados',
      authUsersTotal: 3,
      syncedToPublic: 3,
    })
  );
}

export interface AuthLoginResponse {
  success: boolean;
  user: User;
  session?: any;
  message: string;
}

export async function loginWithApi(email: string, password: string): Promise<AuthLoginResponse> {
  return safeApiCall(
    '/auth/login',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    },
    () => {
      const user = mockStore.getUsers().find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
      if (!user) throw new Error('Usuario o credenciales no válidas');
      return { success: true, user, message: 'Sesión iniciada' };
    }
  );
}

export async function registerWithApi(data: {
  name: string;
  email: string;
  password?: string;
  phone?: string;
  birthday?: string;
  role?: 'client' | 'staff' | 'admin';
}): Promise<AuthLoginResponse> {
  return safeApiCall(
    '/auth/register',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => {
      const user = mockStore.createUser({
        name: data.name,
        email: data.email,
        phone: data.phone,
        birthday: data.birthday,
      });
      if (data.role) mockStore.updateUserRole(user.id, data.role);
      return { success: true, user, message: 'Usuario registrado con éxito' };
    }
  );
}

export async function sendMagicLinkApi(email: string): Promise<{ success: boolean; message: string }> {
  return safeApiCall(
    '/auth/magic-link',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    },
    () => ({ success: true, message: `Enlace mágico enviado a ${email}` })
  );
}

export async function fetchUserProfileByEmail(email: string): Promise<User> {
  return safeApiCall(
    `/auth/profile?email=${encodeURIComponent(email)}`,
    undefined,
    () => {
      const user = mockStore.getUsers().find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
      if (!user) throw new Error('Usuario no encontrado');
      return user;
    }
  );
}

export async function syncOAuthUserApi(data: {
  email: string;
  name?: string;
  avatar_url?: string;
  phone?: string;
}): Promise<{ success: boolean; user: User; isNew?: boolean; message?: string }> {
  return safeApiCall(
    '/auth/oauth-sync',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    },
    () => mockStore.syncOAuthUser(data)
  );
}

export async function resetTestDataApi(): Promise<{ success: boolean; message: string }> {
  return safeApiCall(
    '/admin/reset-test-data',
    { method: 'POST', headers: { 'Content-Type': 'application/json' } },
    () => mockStore.resetTestData()
  );
}
