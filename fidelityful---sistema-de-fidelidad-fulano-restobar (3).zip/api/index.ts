import express from 'express';
import { apiRouter } from '../src/server/routes.ts';
import { getDb } from '../src/server/db.ts';

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

app.use(async (_req, _res, next) => {
  try {
    await getDb();
  } catch (err) {
    console.warn('Database initialization warning on serverless function:', err);
  }
  next();
});

// Support both /api/* and direct rewrite paths
app.use('/api', apiRouter);
app.use('/', apiRouter);

export default app;
